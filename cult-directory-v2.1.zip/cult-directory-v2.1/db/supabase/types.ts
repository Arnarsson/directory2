export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.4"
  }
  public: {
    Tables: {
      bookmarks: {
        Row: {
          created_at: string | null
          id: string
          product_id: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          product_id: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          product_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bookmarks_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bookmarks_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_admin_status"
            referencedColumns: ["id"]
          }
        ]
      }
      categories: {
        Row: {
          created_at: string
          icon: string | null
          id: string
          name: string
        }
        Insert: {
          created_at?: string
          icon?: string | null
          id?: string
          name: string
        }
        Update: {
          created_at?: string
          icon?: string | null
          id?: string
          name?: string
        }
        Relationships: []
      }
      labels: {
        Row: {
          created_at: string
          id: string
          name: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
        }
        Relationships: []
      }
      product_views: {
        Row: {
          id: string
          product_id: string
          viewed_at: string
        }
        Insert: {
          id?: string
          product_id: string
          viewed_at?: string
        }
        Update: {
          id?: string
          product_id?: string
          viewed_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "product_views_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          }
        ]
      }
      products: {
        Row: {
          approved: boolean
          categories: string | null
          codename: string
          created_at: string | null
          description: string
          email: string | null
          featured: boolean
          full_name: string | null
          id: string
          labels: string[] | null
          logo_src: string | null
          product_website: string
          punchline: string
          tags: string[] | null
          twitter_handle: string | null
          user_id: string
          view_count: number | null
        }
        Insert: {
          approved?: boolean
          categories?: string | null
          codename: string
          created_at?: string | null
          description: string
          email?: string | null
          featured?: boolean
          full_name?: string | null
          id?: string
          labels?: string[] | null
          logo_src?: string | null
          product_website: string
          punchline: string
          tags?: string[] | null
          twitter_handle?: string | null
          user_id: string
          view_count?: number | null
        }
        Update: {
          approved?: boolean
          categories?: string | null
          codename?: string
          created_at?: string | null
          description?: string
          email?: string | null
          featured?: boolean
          full_name?: string | null
          id?: string
          labels?: string[] | null
          logo_src?: string | null
          product_website?: string
          punchline?: string
          tags?: string[] | null
          twitter_handle?: string | null
          user_id?: string
          view_count?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "products_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_admin_status"
            referencedColumns: ["id"]
          }
        ]
      }
      tags: {
        Row: {
          created_at: string
          id: string
          name: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
        }
        Relationships: []
      }
      users: {
        Row: {
          avatar_url: string | null
          billing_address: Json | null
          bio: string | null
          company: string | null
          created_at: string | null
          experience_level: string | null
          favorite_tools: string[] | null
          full_name: string | null
          github_handle: string | null
          id: string
          linkedin_handle: string | null
          location: string | null
          onboarding_completed: boolean | null
          payment_method: Json | null
          primary_interests: string[] | null
          profile_completed: boolean | null
          role: string | null
          twitter_handle: string | null
          updated_at: string | null
          website: string | null
        }
        Insert: {
          avatar_url?: string | null
          billing_address?: Json | null
          bio?: string | null
          company?: string | null
          created_at?: string | null
          experience_level?: string | null
          favorite_tools?: string[] | null
          full_name?: string | null
          github_handle?: string | null
          id: string
          linkedin_handle?: string | null
          location?: string | null
          onboarding_completed?: boolean | null
          payment_method?: Json | null
          primary_interests?: string[] | null
          profile_completed?: boolean | null
          role?: string | null
          twitter_handle?: string | null
          updated_at?: string | null
          website?: string | null
        }
        Update: {
          avatar_url?: string | null
          billing_address?: Json | null
          bio?: string | null
          company?: string | null
          created_at?: string | null
          experience_level?: string | null
          favorite_tools?: string[] | null
          full_name?: string | null
          github_handle?: string | null
          id?: string
          linkedin_handle?: string | null
          location?: string | null
          onboarding_completed?: boolean | null
          payment_method?: Json | null
          primary_interests?: string[] | null
          profile_completed?: boolean | null
          role?: string | null
          twitter_handle?: string | null
          updated_at?: string | null
          website?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "users_id_fkey"
            columns: ["id"]
            isOneToOne: true
            referencedRelation: "user_admin_status"
            referencedColumns: ["id"]
          }
        ]
      }
    }
    Views: {
      user_admin_status: {
        Row: {
          created_at: string | null
          email: string | null
          id: string | null
          is_admin: boolean | null
          user_number: number | null
        }
        Relationships: []
      }
    }
    Functions: {
      delete_claim: {
        Args: { claim: string; uid: string }
        Returns: string
      }
      get_category_metrics: {
        Args: Record<PropertyKey, never>
        Returns: {
          month: string
          total: number
        }[]
      }
      get_claims: {
        Args: { uid: string }
        Returns: Json
      }
      get_label_metrics: {
        Args: Record<PropertyKey, never>
        Returns: {
          month: string
          total: number
        }[]
      }
      get_product_metrics: {
        Args: Record<PropertyKey, never>
        Returns: {
          month: string
          total: number
        }[]
      }
      get_profile_completion_percentage: {
        Args: { user_id: string }
        Returns: number
      }
      get_tag_metrics: {
        Args: Record<PropertyKey, never>
        Returns: {
          month: string
          total: number
        }[]
      }
      get_user_bookmark_count: {
        Args: { user_uuid: string }
        Returns: number
      }
      get_user_id_by_email: {
        Args: { user_email: string }
        Returns: string
      }
      get_user_metrics: {
        Args: Record<PropertyKey, never>
        Returns: {
          month: string
          total: number
        }[]
      }
      get_user_products: {
        Args: { user_uuid: string }
        Returns: {
          approved: boolean
          categories: string
          codename: string
          created_at: string
          description: string
          id: string
          logo_src: string
          punchline: string
        }[]
      }
      get_user_products_count: {
        Args: { user_uuid: string }
        Returns: number
      }
      has_admin_users: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      increment_product_view_count: {
        Args: { product_id: string }
        Returns: undefined
      }
      is_auto_promoted_admin: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      is_claims_admin: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      is_product_bookmarked: {
        Args: { product_uuid: string; user_uuid: string }
        Returns: boolean
      }
      is_user_admin: {
        Args: { user_id: string }
        Returns: boolean
      }
      remove_user_admin: {
        Args: { user_id: string }
        Returns: undefined
      }
      set_claim: {
        Args: { claim: string; uid: string; value: Json }
        Returns: string
      }
      set_user_admin: {
        Args: { user_id: string }
        Returns: undefined
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
      DefaultSchema["Views"])
  ? (DefaultSchema["Tables"] &
      DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
      Row: infer R
    }
    ? R
    : never
  : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
  ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
      Insert: infer I
    }
    ? I
    : never
  : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
  ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
      Update: infer U
    }
    ? U
    : never
  : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
  ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
  : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
  ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
  : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
